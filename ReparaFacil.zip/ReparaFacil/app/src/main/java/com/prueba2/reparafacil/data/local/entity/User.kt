package com.prueba2.reparafacil.data.local.entity

data class User(
    val id: Int,
    val name: String,
    val email: String?
)
